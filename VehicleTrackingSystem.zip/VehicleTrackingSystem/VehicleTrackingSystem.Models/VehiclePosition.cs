﻿using System;
namespace VehicleTrackingSystem.Models
{
    public class VehiclePosition : BaseModel
    {
        public int VehiclePositionId { get; set; }
        public int VehicleId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}