﻿using System;
namespace VehicleTrackingSystem.Models
{
    public class User : BaseModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FullName { get; set; }
        public EnumRoleType RoleId { get; set; }
        public bool IsActive { get; set; }
    }

    public enum EnumRoleType
    {
        Admin = 1,
        Vehicle = 2
    }
}