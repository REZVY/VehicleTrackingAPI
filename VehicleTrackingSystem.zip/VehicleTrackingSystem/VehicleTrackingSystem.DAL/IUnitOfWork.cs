﻿using System;
namespace VehicleTrackingSystem.DAL
{
    public interface IUnitOfWork
    {
        void Dispose();
        void SaveChanges();
    }
}
