﻿using System;
using System.Data;
using System.Data.Common;

namespace VehicleTrackingSystem.DAL
{
    public class DbConnectionFactory : IConnectionFactory
    {
        private readonly DbProviderFactory _provider;
        public static string _connectionString;
        public static string providerName;

        public DbConnectionFactory()
        {
           _provider = DbProviderFactories.GetFactory(providerName);
        }

        public IDbConnection Create()
        {
            var connection = _provider.CreateConnection();
            connection.ConnectionString = _connectionString;
            connection.Open();
            return connection;
        }
    }
}
