﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VehicleTrackingSystem.Models;

namespace VehicleTrackingSystem.DAL.Repositories
{
    public class UserRepository : Repository<User>
    {
        private readonly DbContext _context;

        public UserRepository(DbContext context) : base(context)
        {
            _context = context;
        }

        public async Task<IList<User>> GetList()
        {
            using (var command = _context.CreateCommand())
            {
                StringBuilder sb = new StringBuilder();

                sb.Append("SELECT * FROM [dbo].[User]");

                command.CommandText = sb.ToString();

                return await Task.FromResult(ToList(command).ToList());
            }
        }

        public async Task<User> GetByName(string username)
        {
            using (var command = _context.CreateCommand())
            {
                StringBuilder sb = new StringBuilder();

                sb.Append("SELECT * FROM [dbo].[User] where UserName = '" + username + "'");

                command.CommandText = sb.ToString();

                return await Task.FromResult(ToList(command).FirstOrDefault());
            }
        }

        public User GetActiveUserByUsername(string username)
        {
            using (var command = _context.CreateCommand())
            {
                StringBuilder sb = new StringBuilder();

                sb.Append("SELECT * FROM [dbo].[User] where UserName = '" + username + "' and IsActive = 1");

                command.CommandText = sb.ToString();

                return ToList(command).FirstOrDefault();
            }
        }

        public bool IsDuplicate(User user, string type)
        {
            using (var command = _context.CreateCommand())
            {
                StringBuilder sb = new StringBuilder();

                sb.Append("SELECT COUNT(*) FROM [dbo].[User] where UserName = '" + user.UserName.Trim() + "'");
                if (type == "update")
                {
                    sb.Append(" and UserId != " + user.UserId);
                }
                command.CommandText = sb.ToString();

                return (ExecuteScalar(command) > 0);
            }
        }

        public async Task<string> Insert(User user)
        {
            IList<System.Data.IDbCommand> commands = new List<System.Data.IDbCommand>();
            var command = _context.CreateCommand();

            #region Insert User

            string sqlQuery = @"INSERT INTO [dbo].[User]([UserName],[Password]
           ,[FullName],[RoleId],[IsActive],[CreatedBy],[CreatedDate])
            VALUES ('{0}','{1}',N'{2}',{3},'{4}','{5}','{6}')";

            sqlQuery = string.Format(sqlQuery,
                user.UserName,
                user.Password,
                user.FullName,
                user.RoleId,
                user.IsActive,
                user.CreatedBy,
                user.CreatedDate);
            command.CommandText = sqlQuery;
            commands.Add(command);

            #endregion

            var transaction = _context.CreateCommand().Connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted);
            if (ExecuteNonQuery(commands, transaction))
            {
                return await Task.FromResult(user.UserName);
            }
            else
            {
                return await Task.FromResult("");
            }
        }

        public async Task<string> Update(User user)
        {
            IList<System.Data.IDbCommand> commands = new List<System.Data.IDbCommand>();
            var command = _context.CreateCommand();

            #region Update User

            string sqlQuery = @"UPDATE [dbo].[User] SET Password = '{0}', FullName = N'{1}'
                    , RoleId = {2}, IsActive = '{3}',
                    [UpdatedBy] = '{4}',[UpdatedDate] = '{5}' WHERE UserId = {6}";

            sqlQuery = string.Format(sqlQuery,
                user.Password,
                user.FullName,
                user.RoleId,
                user.IsActive,
                user.UpdatedBy,
                user.UpdatedDate,
                user.UserId);
            command.CommandText = sqlQuery;
            commands.Add(command);

            #endregion

            var transaction = _context.CreateCommand().Connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted);
            if (ExecuteNonQuery(commands, transaction))
            {
                return await Task.FromResult(user.UserName.ToString());
            }
            else
            {
                return await Task.FromResult("");
            }
        }
    }
}