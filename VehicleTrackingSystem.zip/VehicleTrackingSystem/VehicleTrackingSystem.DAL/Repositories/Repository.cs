﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using VehicleTrackingSystem.DAL.Extensions;

namespace VehicleTrackingSystem.DAL.Repositories
{
    public class Repository<TEntity> where TEntity : new()
    {
        private readonly DbContext _context;

        public Repository(DbContext context)
        {
            _context = context;
        }

        protected DbContext Context
        {
            get
            {
                return _context;
            }
        }

        protected IEnumerable<TEntity> ToList(IDbCommand command)
        {
            command.CommandTimeout = 0;
            using (var record = command.ExecuteReader())
            {
                List<TEntity> items = new List<TEntity>();
                while (record.Read())
                {
                    items.Add(Map<TEntity>(record));
                }
                return items;
            }
        }

        protected bool ExecuteNonQuery(IDbCommand command)
        {
            command.Transaction = command.Connection.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                command.ExecuteNonQuery();
                command.Transaction.Commit();
                return true;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                command.Transaction.Rollback();
                throw;
            }
        }

        protected bool ExecuteNonQuery(IList<IDbCommand> commands, IDbTransaction transaction)
        {
            int i = 0;
            try
            {
                foreach (IDbCommand command in commands)
                {
                    i++;
                    command.Transaction = transaction;
                    command.CommandTimeout = 0;
                    command.ExecuteNonQuery();
                }
                transaction.Commit();
                return true;
            }
            catch (Exception)
            {
                transaction.Rollback();
                throw;
            }
        }

        protected int ExecuteScalar(IDbCommand command)
        {
            var count = command.ExecuteScalar();
            return count != null ? (int)count : 0;
        }

        protected bool ExecuteBulkNonQuery(IDbCommand command, IDbTransaction transaction)
        {

            command.Transaction = transaction;
            command.ExecuteNonQuery();
            return true;
        }

        protected TEntity Map<TEntity>(IDataRecord record)
        {
            var objT = Activator.CreateInstance<TEntity>();
            foreach (var property in typeof(TEntity).GetProperties())
            {
                if (record.HasColumn(property.Name) && !record.IsDBNull(record.GetOrdinal(property.Name)))
                    property.SetValue(objT, record[property.Name]);
            }
            return objT;
        }

        protected DataTable ToDataTable(IDbCommand command)
        {
            command.CommandTimeout = 0;
            DataTable dataTable = new DataTable();
            SqlCommand cmd = new SqlCommand(command.CommandText, (SqlConnection)command.Connection);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dataTable);

            return dataTable;
        }
    }
}
