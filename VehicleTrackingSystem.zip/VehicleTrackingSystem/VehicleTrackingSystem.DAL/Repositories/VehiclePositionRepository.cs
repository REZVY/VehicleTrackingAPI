﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VehicleTrackingSystem.Models;

namespace VehicleTrackingSystem.DAL.Repositories
{
    public class VehiclePositionRepository : Repository<VehiclePosition>
    {
        private readonly DbContext _context;

        public VehiclePositionRepository(DbContext context) : base(context)
        {
            _context = context;
        }

        public async Task<IList<VehiclePosition>> GetAllPositionsByTime(int vehicleId, DateTime startTime, DateTime endTime)
        {
            using (var command = _context.CreateCommand())
            {
                StringBuilder sb = new StringBuilder();

                sb.Append("SELECT * FROM [dbo].[VehiclePosition] where VehicleId = " + vehicleId +
                    " and CreatedDate BETWEEN " + startTime + " AND " + endTime);

                command.CommandText = sb.ToString();

                return await Task.FromResult(ToList(command).ToList());
            }
        }

        public async Task<VehiclePosition> GetCurrentPosition(int vehicleId)
        {
            using (var command = _context.CreateCommand())
            {
                StringBuilder sb = new StringBuilder();

                sb.Append("SELECT * FROM [dbo].[VehiclePosition] where VehicleId = " + vehicleId +
                    " ORDER BY VehiclePositionId DESC");

                command.CommandText = sb.ToString();

                return await Task.FromResult(ToList(command).FirstOrDefault());
            }
        }

        public async Task<string> SaveVehiclePosition(VehiclePosition vehiclePosition)
        {
            IList<System.Data.IDbCommand> commands = new List<System.Data.IDbCommand>();
            var command = _context.CreateCommand();

            #region Insert Vehicle Position

            string sqlQuery = @"INSERT INTO [dbo].[VehiclePosition]([VehicleId],[Latitude]
           ,[Longitude],CreatedBy],[CreatedDate])
            VALUES ({0},{1},{2},'{3}','{4}')";

            sqlQuery = string.Format(sqlQuery,
                vehiclePosition.VehicleId,
                vehiclePosition.Latitude,
                vehiclePosition.Longitude,
                vehiclePosition.CreatedBy,
                vehiclePosition.CreatedDate);
            command.CommandText = sqlQuery;
            commands.Add(command);

            #endregion

            var transaction = _context.CreateCommand().Connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted);
            if (ExecuteNonQuery(commands, transaction))
            {
                return await Task.FromResult(vehiclePosition.CreatedBy);
            }
            else
            {
                return await Task.FromResult("");
            }
        }
    }
}