﻿using System;
using System.Data;

namespace VehicleTrackingSystem.DAL
{
    public interface IConnectionFactory
    {
        IDbConnection Create();
    }
}
