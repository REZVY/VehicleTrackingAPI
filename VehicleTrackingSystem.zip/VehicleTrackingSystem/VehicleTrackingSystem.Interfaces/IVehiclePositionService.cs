﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VehicleTrackingSystem.Models;

namespace VehicleTrackingSystem.Interfaces
{
    public interface IVehiclePositionService
    {
        Task<IList<VehiclePosition>> GetAllPositionsByTime(int vehicleId, DateTime startTime, DateTime endTime);
        Task<VehiclePosition> GetCurrentPosition(int vehicleId);
        Task<string> SaveVehiclePosition(VehiclePosition vehicle);
    }
}