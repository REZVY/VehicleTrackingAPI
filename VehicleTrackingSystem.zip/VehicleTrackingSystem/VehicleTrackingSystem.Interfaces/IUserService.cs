﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VehicleTrackingSystem.Models;

namespace VehicleTrackingSystem.Interfaces
{
    public interface IUserService
    {
        Task<IList<User>> GetAll();
        Task<User> GetByName(string name);
        User GetActiveUserByUsername(string name);
        Task<string> Save(User user);
        User Login(string userName, string password);
    }
}