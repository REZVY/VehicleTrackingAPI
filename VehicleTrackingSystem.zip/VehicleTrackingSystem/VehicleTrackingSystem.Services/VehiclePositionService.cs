﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VehicleTrackingSystem.DAL;
using VehicleTrackingSystem.DAL.Repositories;
using VehicleTrackingSystem.Interfaces;
using VehicleTrackingSystem.Models;

namespace VehicleTrackingSystem.Services
{
    public class VehiclePositionService : IVehiclePositionService
    {
        private IConnectionFactory connectionFactory;

        public async Task<IList<VehiclePosition>> GetAllPositionsByTime(int vehicleId, DateTime startTime, DateTime endTime)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            using (var context = new DbContext(connectionFactory))
            {
                var rep = new VehiclePositionRepository(context);
                return await rep.GetAllPositionsByTime(vehicleId, startTime, endTime);
            }
        }

        public async Task<VehiclePosition> GetCurrentPosition(int vehicleId)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            using (var context = new DbContext(connectionFactory))
            {
                var rep = new VehiclePositionRepository(context);
                return await rep.GetCurrentPosition(vehicleId);
            }
        }

        public async Task<string> SaveVehiclePosition(VehiclePosition vehiclePosition)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            using (var context = new DbContext(connectionFactory))
            {
                var rep = new VehiclePositionRepository(context);
                return await rep.SaveVehiclePosition(vehiclePosition);
            }
        }
    }
}