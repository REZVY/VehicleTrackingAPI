﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using VehicleTrackingSystem.DAL;
using VehicleTrackingSystem.DAL.Repositories;
using VehicleTrackingSystem.Interfaces;
using VehicleTrackingSystem.Models;

namespace VehicleTrackingSystem.Services
{
    public class UserService : IUserService
    {
        private IConnectionFactory connectionFactory;
        private const string initVector = "tu89geji340t89u2";
        private const int keysize = 256;

        public async Task<IList<User>> GetAll()
        {
            connectionFactory = ConnectionHelper.GetConnection();

            using (var context = new DbContext(connectionFactory))
            {
                var rep = new UserRepository(context);
                return await rep.GetList();
            }
        }

        public async Task<User> GetByName(string name)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            using (var context = new DbContext(connectionFactory))
            {
                var rep = new UserRepository(context);
                return await rep.GetByName(name);
            }
        }

        public User GetActiveUserByUsername(string name)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            using (var context = new DbContext(connectionFactory))
            {
                var rep = new UserRepository(context);
                return rep.GetActiveUserByUsername(name);
            }
        }

        public async Task<string> Save(User user)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            using (var context = new DbContext(connectionFactory))
            {
                var rep = new UserRepository(context);
                if (user.UserId == 0)
                {
                    if (!rep.IsDuplicate(user, ""))
                    {
                        user.Password = Encrypt(user.Password, user.UserName);
                        return await rep.Insert(user);
                    }
                    else
                    {
                        return await Task.FromResult("Duplicate");
                    }
                }
                else
                {
                    if (!rep.IsDuplicate(user, "update"))
                    {
                        return await rep.Update(user);
                    }
                    else
                    {
                        return await Task.FromResult("Duplicate");
                    }
                }
            }
        }

        public User Login(string userName, string password)
        {
            connectionFactory = ConnectionHelper.GetConnection();
            using (var context = new DbContext(connectionFactory))
            {
                var rep = new UserRepository(context);
                var user = rep.GetActiveUserByUsername(userName);

                if (user == null)
                    return null;

                string pass = Decrypt(user.Password, userName);

                if (pass != password)
                    return null;

                return user;
            }
        }

        public static string Encrypt(string plainText, string passPhrase)
        {
            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }

        public static string Decrypt(string cipherText, string passPhrase)
        {
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
            CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] plainTextBytes = new byte[cipherTextBytes.Length];
            int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
            memoryStream.Close();
            cryptoStream.Close();
            return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
        }
    }
}
