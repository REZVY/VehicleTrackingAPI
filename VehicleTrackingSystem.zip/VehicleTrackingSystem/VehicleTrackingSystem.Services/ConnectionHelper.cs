﻿using System;
using VehicleTrackingSystem.DAL;

namespace VehicleTrackingSystem.Services
{
    public static class ConnectionHelper
    {
        public static IConnectionFactory GetConnection()
        {
            return new DbConnectionFactory();
        }
    }
}
