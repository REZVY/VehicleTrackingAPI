﻿using System;
namespace VehicleTrackingSystem.API.Models
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
