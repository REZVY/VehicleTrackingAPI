﻿using System;
using VehicleTrackingSystem.Models;

namespace VehicleTrackingSystem.API.Models
{
    public class AuthenticateResponse
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Token { get; set; }


        public AuthenticateResponse(User user, string token)
        {
            UserId = user.UserId;
            UserName = user.UserName;
            FullName = user.FullName;
            Token = token;
        }
    }
}