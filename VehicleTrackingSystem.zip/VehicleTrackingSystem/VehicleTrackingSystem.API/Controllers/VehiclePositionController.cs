﻿using System;
using System.Threading.Tasks;
using VehicleTrackingSystem.API.Helper;
using VehicleTrackingSystem.Interfaces;
using VehicleTrackingSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace VehicleTrackingSystem.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class VehiclePositionController : ControllerBase
    {
        private readonly IVehiclePositionService _service;
        private readonly IUserService _userService;

        public VehiclePositionController(IVehiclePositionService service, IUserService userService)
        {
            _service = service;
            _userService = userService;
        }

        [HttpGet("GetAllPositionsByTime")]
        public async Task<IActionResult> GetAllPositionsByTime(int vehicleId, DateTime startTime, DateTime endTime)
        {
            var list = await _service.GetAllPositionsByTime(vehicleId, startTime, endTime);
            return Ok(list);
        }

        [HttpGet("GetCurrentPosition")]
        public async Task<IActionResult> GetCurrentPosition(int vehicleId)
        {
            var first = await _service.GetCurrentPosition(vehicleId);
            return Ok(first);
        }

        [HttpPost("SaveVehiclePosition")]
        public async Task<IActionResult> SaveVehiclePosition(VehiclePosition vehiclePosition)
        {
            try
            {
                var vehicle = await _userService.GetByName(User.Identity.Name);
                if(vehicle == null || vehicle.RoleId != EnumRoleType.Vehicle)
                {
                    return NotFound("Vehicle Not Found");
                }
                vehiclePosition.VehicleId = vehicle.UserId;
                vehiclePosition.CreatedBy = User.Identity.Name;
                vehiclePosition.CreatedDate = DateTime.Now;
                var vehicleName = await _service.SaveVehiclePosition(vehiclePosition);
                return (vehicleName == "") ? NotFound(vehicleName) : Ok(new { vehicleName });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
    }
}