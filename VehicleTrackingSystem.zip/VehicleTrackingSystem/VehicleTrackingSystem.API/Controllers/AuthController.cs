﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using VehicleTrackingSystem.API.Models;
using VehicleTrackingSystem.Interfaces;
using VehicleTrackingSystem.Models;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace VehicleTrackingSystem.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IUserService _service;
        private readonly AppSettings _appSettings;


        public AuthController(IConfiguration config, IMapper mapper, IUserService service, IOptions<AppSettings> appSettings)
        {
            _service = service;
            _appSettings = appSettings.Value;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] AuthenticateRequest model)
        {
            try
            {
                var user = _service.Login(model.UserName, model.Password);
                if (user == null)
                    return BadRequest(new { message = "Username or password is incorrect" });

                // authentication successful so generate jwt token
                var token = generateJwtToken(user);

                return Ok(new AuthenticateResponse(user, token));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException.Message.ToString());
            }
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            try
            {
                user.IsActive = true;
                user.CreatedBy = user.UserName;
                user.CreatedDate = DateTime.Now;

                //save customer
                var code = await _service.Save(user);

                return (code == "Duplicate") ? NotFound(code) : Ok(new {code});
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException.Message.ToString());
            }
        }

        // helper methods
        private string generateJwtToken(User user)
        {
            // generate token that is valid for 1 year
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] {
                    new Claim("username", user.UserName.ToString()),
                    new Claim(ClaimTypes.NameIdentifier, user.UserName.ToString()),
                    new Claim(ClaimTypes.Name, user.UserName.ToString())
                }),
                Expires = DateTime.UtcNow.AddYears(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}