﻿using System;
using System.Threading.Tasks;
using VehicleTrackingSystem.API.Helper;
using VehicleTrackingSystem.Interfaces;
using VehicleTrackingSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace VehicleTrackingSystem.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IUserService _service;

        public UserController(IUserService service)
        {
            _service = service;
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            var list = await _service.GetAll();
            return Ok(list);
        }

        [HttpGet("GetByName")]
        public async Task<IActionResult> GetByName(string name)
        {
            var first = await _service.GetByName(name);
            return Ok(first);
        }

        [HttpPost("Save")]
        public async Task<IActionResult> Save(User user)
        {
            try
            {
                if (user.UserId == 0)
                {
                    user.CreatedBy = User.Identity.Name;
                    user.CreatedDate = DateTime.Now;
                }
                else
                {
                    user.UpdatedBy = User.Identity.Name;
                    user.UpdatedDate = DateTime.Now;
                }
                var code = await _service.Save(user);
                return (code == "Duplicate") ? NotFound(code) : Ok(new { code });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
    }
}